using System;
using System.Collections.Generic;
using System.Windows.Forms;


namespace SketchieGemsV2
{
    class Program
    {
        [STAThread]
        static void Main()
        {
            Application.Run(new sgForm());
        }
    }
}
